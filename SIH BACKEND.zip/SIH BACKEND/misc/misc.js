const JWT_SECRET_KEY = "qmwn3RBTVyc498UXIZ";
module.exports = JWT_SECRET_KEY;