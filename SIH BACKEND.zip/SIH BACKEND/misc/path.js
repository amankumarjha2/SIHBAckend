module.exports.questionPath = "/Users/adityaraj/Desktop/SIH BACKEND/questions";
