const OpenAI = require('openai');
module.exports.openai = new OpenAI({
    apiKey: "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"
});